import React, {
    useState,
    useEffect
} from 'react';
import axios from 'axios';
import './styles.css';

function App() {
    const [news, setNews] = useState([]);
    const [category, setCategory] = useState('');
    const [query, setQuery] = useState('');
    const [user, setUser] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        axios.get('/api/news')
            .then(response => {
                setNews(response.data);
            })
            .catch(error => {
                setError(error.message);
            });
    }, []);

    useEffect(() => {
        if (category) {
            axios.get(`/api/news/${category}`)
                .then(response => {
                    setNews(response.data);
                })
                .catch(error => {
                    setError(error.message);
                });
        }
    }, [category]);

    useEffect(() => {
        if (query) {
            axios.get(`/api/news/search?q=${query}`)
                .then(response => {
                    setNews(response.data);
                })
                .catch(error => {
                    setError(error.message);
                });
        }
    }, [query]);

    const handleCategoryChange = (event) => {
        setCategory(event.target.value);
    };

    const handleSearch = (event) => {
        setQuery(event.target.value);
    };

    const handleLogin = (event) => {
        event.preventDefault();
        axios.post('/api/login', {
                email: event.target.email.value,
                password: event.target.password.value
            })
            .then(response => {
                setUser(response.data);
            })
            .catch(error => {
                setError(error.message);
            });
    };

    const handleLogout = () => {
        axios.get('/api/logout')
            .then(response => {
                setUser(null);
            })
            .catch(error => {
                setError(error.message);
            });
    };

    return ( <
        div className = "container mx-auto p-4" >
        <
        header className = "bg-gray-200 py-4" >
        <
        nav className = "flex justify-between items-center" >
        <
        a href = "#"
        className = "text-lg font-bold" > News App < /a> <
        ul className = "flex items-center" >
        <
        li > < a href = "#"
        className = "mr-4" > Home < /a></li >
        <
        li > < a href = "#"
        className = "mr-4" > Categories < /a></li >
        <
        li > < a href = "#"
        className = "mr-4" > Search < /a></li > {
            user ? ( <
                li > < a href = "#"
                className = "mr-4"
                onClick = {
                    handleLogout
                } > Logout < /a></li >
            ) : ( <
                li > < a href = "#"
                className = "mr-4"
                onClick = {
                    handleLogin
                } > Login < /a></li >
            )
        } <
        /ul> <
        /nav> <
        /header> <
        main className = "py-4" > {
            error ? ( <
                div className = "bg-red-100 p-4 rounded" > {
                    error
                } < /div>
            ) : ( <
                NewsFeed news = {
                    news
                }
                />
            )
        } <
        /main> <
        /div>
    );
}

function NewsFeed({
    news
}) {
    return ( <
            ul className = "list-none mb-4" > {
                news.map((article, index) => (