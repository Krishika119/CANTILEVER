const express = require('express');
const app = express();
const mongoose = require('mongoose');
const Product = require('./models/Product');

mongoose.connect('mongodb://localhost/ecommerce', {