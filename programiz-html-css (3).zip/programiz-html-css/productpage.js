import React, { useState, useEffect } from 'react';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import axios from 'axios';

function ProductPage() {
  const [product, setProduct] = useState({});
  const [images, setImages] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [price, setPrice] = useState(0);
  const [filteredReviews, setFilteredReviews] = useState([]);
  const [sortOption, setSortOption] = useState('newest');

  useEffect(() => {
    axios.get(`/api/products/${productId}`)
      .then(response => {
        setProduct(response.data);
        setImages(response.data.images);
        setReviews(response.data.reviews);
        setPrice(response.data.price);
      })
      .catch(error => console.error(error));
  }, [productId]);

  const handleFilterChange = (e) => {
    const filterValue = e.target.value;
    const filteredReviews = reviews.filter(review => review.rating === filterValue);
    setFilteredReviews(filteredReviews);
  };

  const handleSortChange = (e) => {
    const sortValue = e.target.value;
    setSortOption(sortValue);
    const sortedReviews = reviews.sort((a, b) => {
      if (sortValue === 'newest') {
        return b.createdAt - a.createdAt;
      } else if (sortValue === 'oldest') {
        return a.createdAt - b.createdAt;
      } else if (sortValue === 'highestRated') {
        return b.rating - a.rating;
      } else if (sortValue === 'lowestRated') {
        return a.rating - b.rating;
      }
    });
    setFilteredReviews(sortedReviews);
  };

  return (
    <div className="product-page">
      <div className="product-images">
        <Carousel>
          {images.map((image, index) => (
            <div key={index}>
              <img src={image.url} alt={image.alt} />
            </div>
          ))}
        </Carousel>
      </div>
      <div className="product-details">
        <h1>{product.name}</h1>
        <p>{product.description}</p>
        <p>Price: ${price}</p>
        <div className="reviews">
          <h2>Reviews</h2>
          <select value={sortOption} onChange={handleSortChange}>
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
            <option value="highestRated">Highest Rated</option>
            <option value="lowestRated">Lowest Rated</option>
          </select>
          <select value={filteredReviews} onChange={handleFilterChange}>
            <option value="">All</option>
            <option value="1">1 star</option>
            <option value="2">2 stars</option>
            <option value="3">3 stars</option>
            <option value="4">4 stars</option>
            <option value="5">5 stars</option>
          </select>
          <ul>
            {filteredReviews.map((review, index) => (
              <li key={index}>
                <p>{review.text}</p>
                <p>Rating: {review.rating} stars</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default ProductPage;